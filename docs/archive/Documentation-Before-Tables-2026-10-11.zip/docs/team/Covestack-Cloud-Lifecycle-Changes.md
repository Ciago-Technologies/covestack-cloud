# Covestack Cloud — Complete Lifecycle Changes

Prepared 11 October 2026 against committed branding baseline 7ac2719 on
fix/security-baseline. The original checkout is outside this session's writable
roots and has not been modified by this task. Implementation is in
`Claude/covestack-cloud-lifecycle`; root Claude guides and the team ZIP are updated.

## Complete scope

| Kind | Owner | Lifecycle defined; driver/controller status |
|---|---|---|
| compute.instance | Agent | Defined; full driver remains planned |
| db.instance | Agent | Defined; managed PostgreSQL driver remains planned |
| k8s.cluster | Agent | Defined; k3d driver remains planned |
| compute.snapshot | Agent | Defined; snapshot driver remains planned |
| network.load-balancer | Agent | Defined; HTTP LB driver remains planned |
| compute.group | Server | Defined; scheduler/controllers remain planned |
| storage.bucket | Server | Defined; bucket management/controllers remain planned |

MinIO administration/root credentials stay server-side. Groups/buckets are excluded
from agent work and observation schemas. Object S3 operations and accounts, tokens,
SSH keys, tags, catalogs, CLI/doctor/health are inventoried separately as metadata/
policy, not invented agent resource kinds. Server operation and notification state
machines are defined separately. DB resize/migrate/fork states are reserved and
rejected until their operations are implemented in a reviewed contract revision.

## Wire changes and integration

Contract version 1.1.0 requires **kind on observed reports** and **supportedKinds on
heartbeat**. Kind must match the owned stored resource; supportedKinds lists only
installed/tested drivers. Empty capabilities are legal. All resource variants enforce
kind-specific desired/observed values and deleting intent. Progress/health/error must
not acknowledge generation; stale generation is ignored and future generation rejected.
Generated catalog validation supports reachable logical transitions to accommodate
unreported intermediate states; terminal states cannot resurrect. Server operation
transitions are direct, cancellation queued-only, failed attempts terminal with linked
new retries. Notifications use bounded post-commit outbox retries.

Source: contracts/lifecycle-rules.json. Generate FROZEN-STATES.md, OpenAPI and Go/Java
data with generate_lifecycle.py. check_lifecycle.py validates generated-file drift and
our emitted schema subset/all-service fixtures. It is not a general-purpose OpenAPI
validator. Agent API kind-specific spec DTOs, readiness, ownership, timestamp/lease
checks and controller/driver integrations still need implementation. Helpers are not
wired into controllers that do not exist. B must call Java lifecycle validation in
scoped transactions; Anuj validates received work before driver dispatch; C enforces
permissions and capability/ownership boundaries. D maps internal states to provider
DTOs; E/B/C own bucket/management policy. No claim of full service implementation.

## Apply once from Fedora

Do not reapply old security/branding patches. This patch targets baseline 7ac2719:

```bash
cd /run/media/anujtiwari/DevMount/Project-CDAC/kan-cloud
git apply --check /run/media/anujtiwari/DevMount/Claude/Covestack-Cloud-Lifecycle.patch
git apply /run/media/anujtiwari/DevMount/Claude/Covestack-Cloud-Lifecycle.patch
python3 contracts/check_lifecycle.py
python3 contracts/sign_example.py
(cd kan-agent && go test -race ./... && go vet ./...)
(cd kan-server && mvn --batch-mode verify)
git diff --stat
```

Review, stage contracts/Go/Java/docs/CI, commit and push your current branch for
Anuj/B/C review. If the dry check fails, inspect intervening edits rather than force
applying. Existing secrets/environment names, signing algorithm and persistent data
are unchanged. The signed observed fixture's body and expected signature are updated.

## Changed files, resulting lines and reason

Ranges describe changed/new blocks in the prepared copy; deleted-only blocks point
to the resulting insertion location. Earlier security/branding line reports remain
historical. This report is added to docs/team in addition to the files below.

| File | Changed lines | Problem addressed / result |
|---|---|---|
| `.github/workflows/build.yml` | 33–33 | Run lifecycle drift/schema fixture checks in CI alongside existing Go/Java/vector jobs. |
| `README.md` | 22–22, 60–70 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `contracts/CANONICAL-REQUEST.md` | 46–49 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `contracts/FROZEN-STATES.md` | 1–1, 3–6, 8–8, 10–18, 20–203 | Replace incomplete four-kind table with generated full lifecycle reference and failure/deletion rules. |
| `contracts/README.md` | 36–56 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `contracts/check_lifecycle.py` | 1–129 | Offline emitted-schema subset and all-service/negative fixture checks; not a general OpenAPI validator. |
| `contracts/examples/get-work-response-all-services.json` | 1–75 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/examples/heartbeat-request.json` | 1–5 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/examples/observed-reports-all-services.json` | 1–42 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/examples/put-observed-request-k8s.json` | 10–11 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/examples/server-operation-and-notification.json` | 1–8 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/examples/server-resources-all-services.json` | 1–111 | All seven server resources/five agent kinds represented; required kind/capability fields and separate server entities. |
| `contracts/generate_lifecycle.py` | 1–172 | Generate documentation, schemas and Go/Java catalog from one source; CI detects drift. |
| `contracts/internal-api.base.json` | 1–250 | Endpoint scaffold without duplicate lifecycle enums; generated schema owns kind/state vocabulary. |
| `contracts/internal-api.yaml` | 1–46, 48–62, 64–90, 92–110, 112–133, 135–787 | Version1.1.0: kind-specific desired/observed enums, correct deletion flag, server-only exclusions and capability heartbeat. |
| `contracts/lifecycle-rules.json` | 1–522 | Single source for all seven resources, ownership, transitions, success mappings, reserved states and metadata inventory. |
| `contracts/lifecycle-test-vectors.json` | 1–503 | 52 shared acceptance cases for Go/Java, including stale/future reports, failed acknowledgements and resurrection. |
| `contracts/sigv1-vectors.json` | 31–31, 33–33 | Add required kind to the observed body and recompute its signature; signing algorithm unchanged. |
| `docs/ANUJ-PERSON-C-HANDOFF.md` | 122–143 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Anuj-Next-Steps.md` | 153–171 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Audit-2026-10-11.md` | 276–277 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Branding-Changes.md` | 94–95 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Code-Changes.md` | 102–103 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Complete-Working-Setup.md` | 263–263, 271–289 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Current-Setup-Fixes.md` | 95–95, 206–224 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Documentation-Change-Log.md` | 120–121 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Lifecycle-Reference.md` | 1–203 | Replace incomplete four-kind table with generated full lifecycle reference and failure/deletion rules. |
| `docs/team/Covestack-Cloud-Project-Workflow.md` | 63–63, 154–172 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Repository-Layout.md` | 57–75 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-START-HERE.md` | 56–74 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Team-Roles.md` | 45–45, 125–143 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Technical-Design.md` | 117–117, 119–122, 124–128, 130–140, 148–148, 174–174, 212–212 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `docs/team/Covestack-Cloud-Tools.md` | 109–127 | Align current onboarding, service scope, ownership, state/operation terms and mandatory payload fields; historical evidence labeled. |
| `kan-agent/internal/lifecycle/catalog_generated.go` | 1–525 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |
| `kan-agent/internal/lifecycle/validate.go` | 1–150 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |
| `kan-agent/internal/lifecycle/validate_test.go` | 1–77 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |
| `kan-server/src/main/java/com/ciagotech/kan/server/contract/LifecycleData.java` | 1–530 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |
| `kan-server/src/main/java/com/ciagotech/kan/server/contract/LifecycleValidator.java` | 1–88 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |
| `kan-server/src/test/java/com/ciagotech/kan/server/contract/LifecycleValidatorTest.java` | 1–37 | Reusable matching Go/Java validation and shared-vector tests; integration into future services/dispatch remains required. |

## Verification and remaining limits

- Generated files exactly match their source; OpenAPI/CI YAML parses; all positive/
  negative schema fixtures pass, including exclusion of server-owned groups/buckets.
- Both Go and Java pass 52 shared lifecycle vectors. Go race tests/vet and three
  signing vectors pass. Java all sources compile and 15 test methods pass through a
  temporary direct runner against cached dependencies.
- Go tests used installed 1.27.1 with GOTOOLCHAIN=local. Full pinned 1.27.2 and Maven
  verification remain blocked by prior network/dependency restrictions; remote CI
  and live Java/Valkey/Docker acceptance are not claimed.
- Patch dry-check and byte-exact apply verified against original baseline. Markdown
  relative file links checked. No secrets are included in patch/team ZIP.
- Spec DTO constraints, readiness probes, active credential stores, permission checks,
  B/A/C lease/report sequencing, public provider mappings and actual drivers remain
  team work; the lifecycle definitions/validation are now complete for declared scope.
