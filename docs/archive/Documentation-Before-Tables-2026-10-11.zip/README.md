# Covestack Cloud

Local DigitalOcean emulator under construction. Currently this repository contains
shared contracts and Go/Java authentication libraries, not a runnable server/agent.

Product name: **Covestack Cloud**; intended repository slug: `covestack-cloud`.
Existing kan-server/kan-agent folders, KAN_* configuration and signing identifiers
remain compatible. The actual GitHub/local checkout name is still kan-cloud until
its owner renames it. See [team start guide](docs/team/Covestack-Cloud-START-HERE.md).

Baseline 349a2f4 is published on fix/security-baseline. Anuj's config.go is currently
a placeholder; credential/token persistence, app/controllers and full agent remain
pending. Review the baseline PR before claiming runtime readiness.

## Verify the current baseline

Use Java 25, Maven 3.9+, Go 1.27.2 (pinned by toolchain and CI), Python 3.
From repository root:

```bash
python3 contracts/sign_example.py
python3 contracts/check_lifecycle.py
(cd kan-agent && go test -race ./... && go vet ./...)
(cd kan-server && mvn --batch-mode verify)
```

## Local infrastructure

Create `deploy/.env` from `.env.example`; select exact tested image references.
Create `deploy/secrets/postgres_password` containing a random password and copy
`deploy/valkey.conf.example` to `deploy/secrets/valkey.conf`, replacing its password.
Protect local secrets with mode 600. These files are gitignored. Start from root:

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml config
docker compose --env-file deploy/.env -f deploy/docker-compose.yml up -d
```

Compose provides Postgres, authenticated persistent Valkey and Mailpit. MinIO is
not implemented here yet. Existing Postgres volumes retain their original password;
changing the secret file does not rotate an initialized database's credentials.
Do not delete data volumes to rotate credentials. Coordinate database password
rotation with the Java owner and update connection settings together.

## Integration

Read `contracts/CANONICAL-REQUEST.md` and `docs/ANUJ-PERSON-C-HANDOFF.md`.
Go's `sigv1.NewSignedRequest` signs exact body bytes, raw path/query and fresh nonces.
Use HTTPS outside localhost and a client with redirects disabled.
Person C implements `KeyService.findActiveCredential`, with service keys scoped to
an account, and the Bearer token lookup implementation. Public filters are registered but require
these implementations and account-scoped controllers. Agent auth configuration uses Valkey;
there is no production fallback to the in-memory store.

Person B still needs application main/configuration, migrations and account-scoped
controllers. Boot repackage is disabled while this is a library; enable it when the
application entry point lands. Anuj still needs the agent executable, polling and
Docker operations. VM/Docker deployment and real Valkey integration are separate
acceptance checks; unit tests do not establish those are working.

## Complete lifecycle contract

Version1.1.0 is defined in [lifecycle-rules.json](contracts/lifecycle-rules.json).
[State reference](contracts/FROZEN-STATES.md) covers all seven resource kinds and
server operations/notifications/metadata policies. Five agent kinds are capability-
filtered; compute.group and storage.bucket are server-only. New observed reports require kind, and
heartbeat requires supportedKinds. Planned drivers are not operational by declaration.
Go/Java lifecycle helpers and shared vectors exist; B/Anuj must call them from the
future scoped services/client dispatch. Regenerate with
`python3 contracts/generate_lifecycle.py`; CI runs generation/schema fixture checks.
