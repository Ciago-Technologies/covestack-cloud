# Covestack Cloud — Frozen Lifecycle Contract

Version **1.1.0**. Generated from `lifecycle-rules.json`; edit the source
and run `python3 contracts/generate_lifecycle.py`. CI checks generated files.
Contract changes require Anuj/B/C review. Defined services are planned until their
drivers/controllers pass acceptance; vocabulary does not mean implementation.

## Resource lifecycle vocabulary

| Kind / service | Owner | Desired states | Observed states | Terminal state |
|---|---|---|---|---|
| `compute.instance` — Droplets / compute instances | agent | `active`, `off`, `archive` | `new`, `provisioning`, `starting`, `active`, `stopping`, `off`, `deleting`, `archive`, `error` | `archive` |
| `db.instance` — Managed PostgreSQL | agent | `online`, `stopped`, `deleted` | `creating`, `starting`, `online`, `stopping`, `stopped`, `deleting`, `deleted`, `error` | `deleted` |
| `k8s.cluster` — Kubernetes / bounded k3d cluster | agent | `active`, `deleted` | `provisioning`, `running`, `degraded`, `deleting`, `deleted`, `error` | `deleted` |
| `compute.group` — Autoscaling groups | server | `active`, `deleted` | `new`, `active`, `scaling`, `degraded`, `deleting`, `deleted`, `error` | `deleted` |
| `compute.snapshot` — Compute snapshots | agent | `available`, `deleted` | `creating`, `available`, `deleting`, `deleted`, `error` | `deleted` |
| `network.load-balancer` — HTTP load balancers | agent | `active`, `deleted` | `new`, `provisioning`, `active`, `degraded`, `deleting`, `deleted`, `error` | `deleted` |
| `storage.bucket` — Spaces-compatible buckets | server | `available`, `deleted` | `creating`, `available`, `deleting`, `deleted`, `error` | `deleted` |

## Convergence, deletion and failure

- Desired state is intent; observed state is reality. Progress/degraded/error is not success.
- Set `deleting=true` exactly for deletion intent: `archive` for instances, `deleted` otherwise.
- Set observedGeneration only to the current target generation after the matching stable state is reached. Progress/errors/health omit it or use null.
- Stale generations return `applied=false`; future/invalid generations are rejected. Actual timestamp, account and agent lease/fencing checks belong in B/C services.
- Each observed report includes kind and observedAt; kind must match the stored owned resource. Groups and buckets are server-owned and cannot be agent reports/work.
- Every heartbeat advertises supportedKinds; the server filters work accordingly. Reject unknown kinds; never mark unsupported work successful.
- Work, known IDs and cleanup remain account/agent scoped. Outages or incomplete known-ID responses never authorize deletion.
- No terminal-state resurrection. Desired deletion intent cannot be reversed by retries; GC waits for teardown acknowledgement. Failure does not acknowledge the target generation.
- Logical transitions below may have unreported intermediate states. Validation permits reachable states, including same-state reports, without traversing a terminal state. Observations alone do not authorize side effects.
- Cancellation applies only to queued operations. A failed operation attempt is terminal; a retry is a new linked attempt.

## compute.instance

active only after container and required readiness checks succeed; off after intentional stop; archive after owned workload teardown.

Success mapping: `active` → `active`; `off` → `off`; `archive` → `archive`.

| From | Allowed next logical states |
|---|---|
| `new` | `provisioning`, `deleting`, `error` |
| `provisioning` | `active`, `off`, `deleting`, `error` |
| `starting` | `active`, `deleting`, `error` |
| `active` | `stopping`, `deleting`, `error` |
| `stopping` | `off`, `deleting`, `error` |
| `off` | `starting`, `deleting`, `error` |
| `deleting` | `archive`, `error` |
| `archive` | Terminal; no outgoing transition |
| `error` | `provisioning`, `starting`, `stopping`, `deleting` |

## db.instance

online requires successful database connection/readiness; preserve data volumes through stop/recreate; deletion follows explicit retention policy.

Success mapping: `online` → `online`; `stopped` → `stopped`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `creating` | `online`, `stopped`, `deleting`, `error` |
| `starting` | `online`, `deleting`, `error` |
| `online` | `stopping`, `deleting`, `error` |
| `stopping` | `stopped`, `deleting`, `error` |
| `stopped` | `starting`, `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `creating`, `starting`, `stopping`, `deleting` |

Reserved future states (not accepted in this contract): `resizing`, `migrating`, `forking`. Add schemas/operations/tests in a reviewed revision before enabling them.

## k8s.cluster

running requires reachable Kubernetes API and required nodes ready; degraded is not successful convergence.

Success mapping: `active` → `running`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `provisioning` | `running`, `degraded`, `deleting`, `error` |
| `running` | `degraded`, `deleting`, `error` |
| `degraded` | `running`, `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `provisioning`, `deleting` |

## compute.group

active requires desired capacity of healthy children; scaling includes pending reservations; deleted only after scoped child policy completes; never agent work.

Success mapping: `active` → `active`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `new` | `scaling`, `active`, `deleting`, `error` |
| `active` | `scaling`, `degraded`, `deleting`, `error` |
| `scaling` | `active`, `degraded`, `deleting`, `error` |
| `degraded` | `scaling`, `active`, `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `scaling`, `deleting` |

## compute.snapshot

available requires immutable account-scoped image persisted and inspected; container snapshots exclude mounted volumes and VM memory.

Success mapping: `available` → `available`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `creating` | `available`, `deleting`, `error` |
| `available` | `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `creating`, `deleting` |

## network.load-balancer

active requires valid configuration, successful reload, reachable listener and healthy required members; empty/unhealthy targets are degraded.

Success mapping: `active` → `active`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `new` | `provisioning`, `deleting`, `error` |
| `provisioning` | `active`, `degraded`, `deleting`, `error` |
| `active` | `degraded`, `deleting`, `error` |
| `degraded` | `active`, `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `provisioning`, `deleting` |

## storage.bucket

available requires physical MinIO bucket and account-scoped access policy; delete empty buckets by default, require explicit authorization to purge objects; server-managed through trusted MinIO administration, with root credentials kept server-side.

Success mapping: `available` → `available`; `deleted` → `deleted`.

| From | Allowed next logical states |
|---|---|
| `creating` | `available`, `deleting`, `error` |
| `available` | `deleting`, `error` |
| `deleting` | `deleted`, `error` |
| `deleted` | Terminal; no outgoing transition |
| `error` | `creating`, `deleting` |

## Server-owned operation and notification lifecycles

### operation

cancelled only before execution; failures are terminal for that attempt; retry creates a linked new attempt; complete only on confirmed target convergence.

| From | Allowed next |
|---|---|
| `queued` | `running`, `failed`, `cancelled` |
| `running` | `completed`, `failed` |
| `completed` | Terminal |
| `failed` | Terminal |
| `cancelled` | Terminal |

### notification

post-commit outbox only; bounded retry policy; SMTP failure never rolls back a committed resource operation; permanent failures remain failed.

| From | Allowed next |
|---|---|
| `queued` | `delivering`, `failed` |
| `delivering` | `delivered`, `failed` |
| `failed` | `queued` |
| `delivered` | Terminal |

## Services without agent resource lifecycles

| Service | Owner | Policy |
|---|---|---|
| Accounts / membership | server | Account activation/suspension and memberships belong to authorization policy, not agent resource work. |
| Access keys / Bearer tokens | server | Active/revoked/expired eligibility, key kind and permissions; no resource lifecycle or agent work. |
| SSH keys | server | Account-scoped metadata; validated public keys; referenced only by owned instances. |
| Tags | server | Account-scoped metadata and associations; reserved ownership labels are not editable user tags. |
| Regions / sizes / images catalogs | server | Read-only provider metadata; snapshots have their own resource lifecycle. |
| Spaces objects | storage | S3 put/get/list/delete behavior within an owned bucket; no asynchronous resource-state enum. |
| CLI / doctor / health | client/server | API clients/status endpoints, not agent resource kinds; detailed doctor requires authentication. |

## Provider mapping and storage boundaries

These are internal states. D maps them to provider DTOs/status vocabulary; internal
strings must not be copied blindly into public responses. Operation statuses are
separate from resource states. E/C define administrative credential/account policy.
MinIO/Postgres/Valkey/Mailpit daemon readiness is infrastructure health, not a new
agent resource kind. Managed databases are account resources; control-plane Postgres
is infrastructure. Storage buckets/objects are not compute snapshots.

## Example: Kubernetes convergence

Java creates desiredState=active, state=provisioning, generation=1. Agent reports
kind=k8s.cluster, state=running, observedAt and observedGeneration=1 only after
readiness. Delete sets desiredState=deleted and deleting=true, increments generation;
deleting progress omits observedGeneration, then deleted acknowledges that generation.

## Acceptance

Run `python3 contracts/check_lifecycle.py`, Go lifecycle tests, Java lifecycle tests
and real scoped controller/driver integration. All planned resource kinds have examples;
groups/buckets appear only in server-resource examples. Do not claim those examples
prove a service is operational.
